from document import Document
from re import Pattern

from ir_core import load_documents_from_url as core_load
from ir_core import linear_boolean_search as core_search
from ir_core import remove_stopwords_by_list as core_list
from ir_core import remove_stopwords_by_frequency as core_freq


def remove_stopwords_by_list(doc: Document, stopwords: set[str]):
    core_list(doc, stopwords)


def remove_stopwords_by_frequency(doc, collection: list[Document], common_frequency: float, rare_frequency: float):
    core_freq(doc, collection, common_frequency, rare_frequency)


def load_documents_from_url(url: str, author: str, origin: str, start_line: int, end_line: int,
                            search_pattern: Pattern[str]) -> list[Document]:
    return core_load(url, author, origin, start_line, end_line, search_pattern)


def linear_boolean_search(term, collection, stopword_filtered=False):
    return core_search(term, collection, stopword_filtered)