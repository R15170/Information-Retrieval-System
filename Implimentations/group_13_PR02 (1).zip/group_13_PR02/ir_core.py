import urllib.request
import re
from document import Document

def clean_text(text: str) -> str:
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'[^\w\s\']', '', text)
    return text.strip()

def tokenize(text: str) -> list[str]:
    return clean_text(text).split()


def load_documents_from_url(url: str, author: str, origin: str, start_line: int, end_line: int,
                            search_pattern: re.Pattern) -> list[Document]:
    """Task 2 - Final version"""
    try:
        with urllib.request.urlopen(url) as response:
            text = response.read().decode('utf-8', errors='ignore')
    except Exception:
        return []

    lines = text.splitlines()
    relevant_text = '\n'.join(lines[start_line-1:end_line])

    documents = []
    matches = list(search_pattern.finditer(relevant_text))

    for i, match in enumerate(matches):
        title_raw = match.group(1).strip() if match.group(1) else ""
        title = re.sub(r'\s+', ' ', title_raw).strip()
        
        # Skip bad titles
        bad_titles = {"life of aesop", "contents", "preface", "index", "footnotes", "aesop’s fables"}
        if not title or title.lower() in bad_titles or len(title) < 5:
            continue
        
        content = match.group(2).strip() if len(match.groups()) > 1 else match.group(0).strip()
        
        raw_text = re.sub(r'\s+', ' ', content).strip()
        terms = tokenize(content)
        
        doc = Document(
            document_id=len(documents),
            title=title,
            raw_text=raw_text,
            terms=terms,
            author=author,
            origin=origin
        )
        documents.append(doc)

    return documents


def linear_boolean_search(term: str, collection: list[Document], stopword_filtered: bool = False):
    """Task 3"""
    results = []
    term_lower = term.lower().strip()
    
    for doc in collection:
        if stopword_filtered:
            search_terms = getattr(doc, '_filtered_terms', doc.terms)
        else:
            search_terms = doc.terms
        
        found = any(t.lower() == term_lower for t in search_terms)
        score = 1 if found else 0
        results.append((score, doc))
    
    results.sort(key=lambda x: (-x[0], getattr(x[1], 'document_id', 0)))
    return results


def remove_stopwords_by_list(doc: Document, stopwords: set[str]):
    """Task 4 - List based (keep original case)"""
    stop_lower = {s.lower().strip() for s in stopwords if s.strip()}
    filtered = [term for term in doc.terms if term.lower() not in stop_lower]
    doc._filtered_terms = filtered


def remove_stopwords_by_frequency(doc: Document, collection: list[Document], 
                                common_frequency: float = 0.9, rare_frequency: float = 0.2):
    """Task 4 - Frequency based"""
    if not collection:
        doc._filtered_terms = doc.terms[:]
        return

    term_doc_count = {}
    total_docs = len(collection)
    
    for d in collection:
        unique = {t.lower().strip() for t in d.terms if t.strip()}
        for t in unique:
            term_doc_count[t] = term_doc_count.get(t, 0) + 1
    
    doc_freq = {t: count / total_docs for t, count in term_doc_count.items()}
    
    filtered = []
    for term in doc.terms:
        t_lower = term.lower().strip()
        df = doc_freq.get(t_lower, 0.0)
        if rare_frequency < df < common_frequency:
            filtered.append(term)
    
    doc._filtered_terms = filtered